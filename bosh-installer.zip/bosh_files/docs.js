$(document).ready(function() {
  $(".docs table").addClass("table");
});
